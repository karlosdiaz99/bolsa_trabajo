<!DOCTYPE html>
<html >
<head>
  <title>Bolsa de trabajo</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
      <link href="estilo10.css" rel="Stylesheet"/>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
<header>
  <div id="sfcwhfazg5pp5cscswpm1m9uxxmsfbb5abb"></div>
                <script type="text/javascript" src="https://counter5.wheredoyoucomefrom.ovh/private/counter.js?c=whfazg5pp5cscswpm1m9uxxmsfbb5abb&down=async" async></script><br><noscript><a href="https://www.contadorvisitasgratis.com" title="contador de entradas"><img src="https://counter5.wheredoyoucomefrom.ovh/private/contadorvisitasgratis.php?c=whfazg5pp5cscswpm1m9uxxmsfbb5abb" border="0" title="contador de entradas" alt="contador de entradas"></a></noscript>

  <div class="row">
                <div class="col-lg-4 ">
                <img class="logoMex" src="imagenes/TECNACMEX.png"width="250" height="100" align="letf">     
                </div>
                <div class="col-lg-4 text-center" >
                  <img class="logoITO" src="imagenes/imagenlogo.png" width="100" height="100">
                    <p class="encabezado text-center">
                        </p><h3>Tecnológico Nacional de México </h3>
                        <h4>Instituto Tecnológico de Oaxaca </h4>
                    <p></p>
                </div>
            <div class="col-lg-4">
                    <img class="logoSEP" src="imagenes/SEP.png"width="250" height="100">
                </div>
            </div>
 
<div class="container">
  <h2></h2>

  <nav>
        <ul>
          <li class="submenu">
            <a href="accesoVinculacion.php" ><span class="icon-user"></span>Oficina de vinculacion<span class="caret icon-circle-down"></span></a>
            
          </li>
          <li class="submenu">
            <a href="accesoEgresado.php"><span class="icon-book2"></span>Egresados<span class="caret icon-circle-down"></span></a>
              
          </li>
          <li>
            <a href="accesoEmpresa.php"><span class="icon-tie"></span>Empresas<span class="caret icon-circle-down"></span></a>
            
          </li>
        </ul>
    </nav>


  <div class="panel panel-primary">
      <div class="panel-heading">BOLSA DE TRABAJO</div>
      <div class="panel-body">
                    Portal Bolsa de Trabajo del Instituto Tecnológico de Oaxaca.
                    <br>
                    La Subdirección de Planeación y Vinculación a través del Departamento 
                    de Gestión Tecnológica y Vinculación en apoyo a los <i>Egresados</i> 
                    de esta Institucion genera un portal web en donde las empresas 
                    dan a conocer las vacantes que ofrecen, para las diferentes 
                    carreras que se imparten en este Instituto con la finalidad 
                    de ofrecer nuevas oportunidades, de empleo a nuestros <i>Egresados</i> 
                    en sus diferentes niveles.</div>
    </div>
 

    <div class="panel panel-primary">
      <div class="panel-heading">MISION</div>
      <div class="panel-body">
										Somos un instrumento de desarrollo de la comunidad, 
                    con el compromiso de formar profesionistas de excelencia, 
                    capaces de responder de manera eficiente y específica a las 
                    necesidades con calidad, productividad y con una visión nacional 
                    e internacional para el presente y el futuro.</div>
    </div>

        <div class="panel panel-primary">
      <div class="panel-heading">VISION</div>
      <div class="panel-body">
        Ser la mejor institución de educación superior tecnológica en la región y del país reconocida y acreditada internacionalmente como una institución de calidad.
      </div>
    </div>
</div>
</header>

  <div class="piepag1" class="form-control">
      <p>
        Instituto Tecnológico de Oaxaca. <br>Departamento de Gestión Tecnológica y Vinculación <br>
        vin_oaxaca@tecnm.mx.<br>
        Tel&eacute;fono: 51 3 23 47       
      </p>
  </div>
</body>
</html>
